
function close(){
	window.close();
	self.close();
}