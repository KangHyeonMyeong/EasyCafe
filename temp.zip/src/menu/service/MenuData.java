package menu.service;

import model.Menu;

public class MenuData {
	private Menu menu;
	
	public MenuData(Menu menu) {
		this.menu=menu;
	}

	public Menu getMenu() {
		return menu;
	}

}
