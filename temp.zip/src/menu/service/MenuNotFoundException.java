package menu.service;

public class MenuNotFoundException extends RuntimeException {
	
	

}
