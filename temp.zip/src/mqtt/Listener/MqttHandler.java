package mqtt.Listener;

public interface MqttHandler {
	public void ControlData(String data);
}
