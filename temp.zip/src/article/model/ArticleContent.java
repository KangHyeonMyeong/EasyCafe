package article.model;

public class ArticleContent {

	private Integer num;
	private String content;
	
	public ArticleContent(Integer num, String content) {
		this.num = num;
		this.content = content;
	}

	public Integer getNum() {
		return num;
	}

	public String getContent() {
		return content;
	}
	
	
}
