package article.model;

public class Writer {
	private String e_mail;
	
	public Writer(String e_mail) {
		this.e_mail = e_mail;
	}

	public String getE_mail() {
		return e_mail;
	}
	
}
