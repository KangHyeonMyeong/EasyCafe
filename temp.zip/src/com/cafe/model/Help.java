package com.cafe.model;

import java.util.Date;

public class Help {
	
	private int num;
	private String title;
	private Date notice_time;
	private String content;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getNotice_time() {
		return notice_time;
	}

	public void setNotice_time(Date notice_time) {
		this.notice_time = notice_time;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	

}
